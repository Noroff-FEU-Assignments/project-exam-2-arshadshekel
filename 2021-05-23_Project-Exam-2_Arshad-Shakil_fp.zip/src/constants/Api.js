export const API = "https://holidaze-backup-1.herokuapp.com/hotels/";
export const LOGINURL = "https://holidaze-backup-1.herokuapp.com/auth/local";
export const CONTACTURL =
  "https://holidaze-backup-1.herokuapp.com/contact-forms/";
export const ENQUIRYURL = "https://holidaze-backup-1.herokuapp.com/Enquiries/";
export const ADDHOTELS = "https://holidaze-backup-1.herokuapp.com/Hotels";

export const GMAPSAPI = "AIzaSyAno-J9N2_6rNDtoA0VmkJU5IqVXQq7DEk";
